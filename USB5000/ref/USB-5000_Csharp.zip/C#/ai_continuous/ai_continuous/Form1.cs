﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;   //必须添加，不然DllImport报错
using System.Threading;

namespace usb_3xxx_ai_continuous
{
    public partial class Form1 : Form
    {
        int DevIndex;
        int Running;
        byte[] Model = new byte[4];
        CheckBox[] checkboxAi = new CheckBox[24];
        TextBox[] textboxAiValue = new TextBox[24];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int temp;
            int i;

            temp = USB5000DLL.FindUSB5DAQ();

            if (temp > 0)
            {
                for (i = 0; i < temp; i++)
                {
                    comboboxDeviceIndex.Items.Add(i);
                }
                comboboxDeviceIndex.SelectedIndex = 0;
                btnStart.Enabled = true;
            }
            else
            {
                btnStart.Enabled = false;
            }

            for (i = 0; i < 16; i++)
            {
                checkboxAi[i] = new CheckBox();
                checkboxAi[i].Width = 60;
                checkboxAi[i].Text = "Ai " + i;
                checkboxAi[i].Left = 20 + 75 * (i / 8);
                checkboxAi[i].Top = 20 + (i % 8) * 20;
                GroupBox1.Controls.Add(checkboxAi[i]);

                textboxAiValue[i] = new TextBox();
                textboxAiValue[i].Width = 50;
                textboxAiValue[i].Left = 20 + 55 * (i % 8);
                textboxAiValue[i].Top = 20 + (i / 8) * 60;
                GroupBox2.Controls.Add(textboxAiValue[i]);
            }

            for (i = 0; i < 8; i++)
            {
                checkboxAi[i].Checked = true;
            }

            btnStop.Enabled = false;
            Running = 0;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            int i;
            int j;
            int temp;
            byte[] SN = new byte[8];
            byte sel;

            //获取设备索引号
            DevIndex = comboboxDeviceIndex.SelectedIndex;

            //打开指定索引号的设备
            temp = USB5000DLL.USB5OpenDevice(DevIndex);

            //显示设备序列号
            temp = USB5000DLL.USB5GetDeviceSN(DevIndex, SN);
            textboxSN.Text = "SN: " + System.Text.Encoding.ASCII.GetString(SN);

            //-----------------------------------------
            //Ai 相关的设置

            //对 16 个通道进行配置
            for(i = 0; i < 16; i++)
            {
                //选择是否要启用该通道
                temp = USB5000DLL.SetUSB5AiChanSel(DevIndex, (byte)i, (byte)(checkboxAi[i].CheckState));
                //设置该通道的量程
                temp = USB5000DLL.SetUSB5AiRange(DevIndex, (byte)i, (float)10);

                //清空所有的 Ai 显示
                textboxAiValue[i].Text = "";
             }

            //设置采集模式为 连续采集 模式
            temp = USB5000DLL.SetUSB5AiSampleMode(DevIndex, 0);

            //设置 Ai 输入的采样周期为 100000 ns，即 100us，采样率为 10kHz
            temp = USB5000DLL.SetUSB5AiSampleRate(DevIndex, 100000);

            //设置 Ai 触发源为软件触发
            temp = USB5000DLL.SetUSB5AiTrigSource(DevIndex, 0);

            //设置 Ai 采样时钟为 Ai 内部采样时钟
            temp = USB5000DLL.SetUSB5AiConvSource(DevIndex, 0);

            //设置 Ai 预触发点数为 0
            temp = USB5000DLL.SetUSB5AiPreTrigPoints(DevIndex, 0);

            //清空一次 AiFifo
            temp = USB5000DLL.SetUSB5ClrAiFifo(DevIndex);

            //启动一次软件触发
            temp = USB5000DLL.SetUSB5AiSoftTrig(DevIndex);


            //启动 Timer1
            timer1.Interval = 5;
            timer1.Enabled = true;
            btnStart.Enabled = false;
            btnStop.Enabled = true;
            Running = 1;
        }

        private void CloseDevice()
        {
            int temp;

            timer1.Enabled = false;
            Thread.Sleep(100);

            //清除硬件触发标志
            temp = USB5000DLL.SetUSB5ClrAiTrigger(DevIndex);
            //清空 Ai Fifo
            temp = USB5000DLL.SetUSB5ClrAiFifo(DevIndex);

            //关闭设备
            temp = USB5000DLL.USB5CloseDevice(DevIndex);

            btnStart.Enabled = true;
            btnStop.Enabled = false;
            Running = 0;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            CloseDevice();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int i;
            int j;
            int temp;
            float[] ai = new float[4800000];
            byte[] di = new byte[100];
            float average;

            //------------------------------------------------
            //Analog Input 相关的功能

            //从 AiFifo 中每个通道读出 1000 个数，存放在 ai 数组中
            //每次读出来的数据连在一起，将是连续无间断采集得到的一组数据
            temp = USB5000DLL.USB5GetAi(DevIndex, 1000, ai, 1000);

            //显示 AiFifo 中还有多少个数据点没被读出来
            //在长时间连续无间断采集的应用中，需注意 temp 数值的变化
            //如果 temp 值在逐渐增大，说明数据处理速度不够快，导致了数据积压在 AiFifo 中
            textboxFifoNum.Text = temp.ToString();

            temp = 0;
            //计算本次采集一共选择了多少个通道
            for(i = 0; i < 16; i++)
            {
                temp = temp + (byte)(checkboxAi[i].CheckState);
            }

            //计算各个通道测量电压的平均值，并显示
            for(j = 0; j < temp; j++)
            {
                average = 0;
                for(i = 0; i < 1000; i++)
                {
                    average = average + ai[j * 1000 + i];
                }
                average = average / 1000;
                textboxAiValue[j].Text = average.ToString("F4");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Running == 1)
            {
                CloseDevice();
            }
            
        }
    }

    class USB5000DLL
    {
        [DllImport("USB5000.dll")]
        public static extern int FindUSB5DAQ();
        [DllImport("USB5000.dll")]
        public static extern int USB5OpenDevice(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int USB5CloseDevice(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDeviceSN(int DevIndex, byte[] SN);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDeviceModel(int DevIndex, byte[] Model);

        //--------------------------------------------------------------------------
        // Ananlog Input Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSampleMode(int DevIndex, byte AiSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiRange(int DevIndex, byte Chan, float AiRange);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiChanSel(int DevIndex, byte Chan, byte Sel);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiTrigSource(int DevIndex, byte AiTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiConvSource(int DevIndex, byte AiConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiPreTrigPoints(int DevIndex, uint AiPreTrigPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiOneShotPoints(int DevIndex, uint AiOneShotPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAiFifo(int DevIndex);

        //--------------------------------------------------------------------------
        // Digital I/O Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSampleMode(int DevIndex, byte DiSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiTrigSource(int DevIndex, byte DiTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiConvSource(int DevIndex, byte DiConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiPreTrigPoints(int DevIndex, uint DiPreTrigPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiOneShotPoints(int DevIndex, uint DiOneShotPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDiFifo(int DevIndex);

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSampleMode(int DevIndex, byte DoSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoTrigSource(int DevIndex, byte DoTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoConvSource(int DevIndex, byte DoConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoCycle(int DevIndex, uint DoCycle);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoDataFifo(int DevIndex, uint[] Value, uint Len);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDoFifo(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoWaveCtrl(int DevIndex, uint Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoImmediately(int DevIndex, uint Chan, uint Value);

        //--------------------------------------------------------------------------
        // Ananlog Output Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSampleRate(int DevIndex, byte Chan, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSampleMode(int DevIndex, byte Chan, byte AoSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoTrigSource(int DevIndex, byte Chan, byte AoTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoConvSource(int DevIndex, byte Chan, byte AoConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoCycle(int DevIndex, byte Chan, byte AoCycle);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoDataFifo(int DevIndex, byte Chan, float[] Voltage, uint Len);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAoFifo(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSync(int DevIndex, byte Chans);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoImmediately(int DevIndex, byte Chan, float Voltage);

        //--------------------------------------------------------------------------
        // Trig Control

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSoftTrig(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5GlobalSoftTrig(int DevIndex);

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAiTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDiTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDoTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAoTrigger(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrGlobalSoftTrig(int DevIndex);

        //--------------------------------------------------------------------------
        // Sync Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ExtTrigOutSource(int DevIndex, byte Source);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ExtConvOutSource(int DevIndex, byte Source);

        //--------------------------------------------------------------------------
        // Get Data Acquired

        [DllImport("USB5000.dll")]
        public static extern int USB5GetAi(int DevIndex, uint Points, float[] Ai, int TimeOut);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDi(int DevIndex, uint Points, byte[] Di, int TimeOut);
    }
}
