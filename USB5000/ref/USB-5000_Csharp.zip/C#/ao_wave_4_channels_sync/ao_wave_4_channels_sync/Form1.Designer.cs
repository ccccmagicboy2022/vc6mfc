﻿namespace usb_3xxx_ao_wave_4_channels_sync
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.textboxSN = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.comboboxDeviceIndex = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // textboxSN
            // 
            this.textboxSN.Location = new System.Drawing.Point(254, 12);
            this.textboxSN.Name = "textboxSN";
            this.textboxSN.Size = new System.Drawing.Size(100, 21);
            this.textboxSN.TabIndex = 9;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(360, 10);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 8;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(44, 15);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(77, 12);
            this.Label1.TabIndex = 7;
            this.Label1.Text = "DeviceIndex:";
            // 
            // comboboxDeviceIndex
            // 
            this.comboboxDeviceIndex.FormattingEnabled = true;
            this.comboboxDeviceIndex.Location = new System.Drawing.Point(127, 12);
            this.comboboxDeviceIndex.Name = "comboboxDeviceIndex";
            this.comboboxDeviceIndex.Size = new System.Drawing.Size(121, 20);
            this.comboboxDeviceIndex.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 52);
            this.Controls.Add(this.textboxSN);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.comboboxDeviceIndex);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox textboxSN;
        internal System.Windows.Forms.Button btnStart;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ComboBox comboboxDeviceIndex;
    }
}

