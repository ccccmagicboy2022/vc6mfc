﻿namespace usb_3xxx_ao_wave_pc_infinite
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.textboxRounds = new System.Windows.Forms.TextBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.textboxSN = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.comboboxDeviceIndex = new System.Windows.Forms.ComboBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(156, 41);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(23, 12);
            this.Label3.TabIndex = 17;
            this.Label3.Text = "SN:";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(24, 68);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(155, 12);
            this.Label2.TabIndex = 16;
            this.Label2.Text = "WaveData Download Rounds:";
            // 
            // textboxRounds
            // 
            this.textboxRounds.Location = new System.Drawing.Point(185, 65);
            this.textboxRounds.Name = "textboxRounds";
            this.textboxRounds.Size = new System.Drawing.Size(121, 21);
            this.textboxRounds.TabIndex = 15;
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(452, 10);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 14;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // textboxSN
            // 
            this.textboxSN.Location = new System.Drawing.Point(185, 38);
            this.textboxSN.Name = "textboxSN";
            this.textboxSN.Size = new System.Drawing.Size(121, 21);
            this.textboxSN.TabIndex = 13;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(344, 10);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 12;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(102, 15);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(77, 12);
            this.Label1.TabIndex = 11;
            this.Label1.Text = "DeviceIndex:";
            // 
            // comboboxDeviceIndex
            // 
            this.comboboxDeviceIndex.FormattingEnabled = true;
            this.comboboxDeviceIndex.Location = new System.Drawing.Point(185, 12);
            this.comboboxDeviceIndex.Name = "comboboxDeviceIndex";
            this.comboboxDeviceIndex.Size = new System.Drawing.Size(121, 20);
            this.comboboxDeviceIndex.TabIndex = 10;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 98);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.textboxRounds);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.textboxSN);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.comboboxDeviceIndex);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox textboxRounds;
        internal System.Windows.Forms.Button btnStop;
        internal System.Windows.Forms.TextBox textboxSN;
        internal System.Windows.Forms.Button btnStart;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ComboBox comboboxDeviceIndex;
        private System.Windows.Forms.Timer timer1;
    }
}

