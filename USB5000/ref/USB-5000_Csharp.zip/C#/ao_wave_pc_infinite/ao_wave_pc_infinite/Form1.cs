﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;   //必须添加，不然DllImport报错
using System.Threading;

namespace usb_3xxx_ao_wave_pc_infinite
{
    public partial class Form1 : Form
    {
        int DevIndex;
        int Running;
        byte[] Model = new byte[4];
        CheckBox[] checkboxAi = new CheckBox[24];
        TextBox[] textboxAiValue = new TextBox[24];
        CheckBox[] checkboxDi = new CheckBox[4];
        CheckBox[] checkboxDo = new CheckBox[4];

        float[] WaveData = new float[1000];
        Random rd = new Random();
        uint Rounds;

        Thread threadDownload;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int temp;
            int i;

            temp = USB5000DLL.FindUSB5DAQ();
            if (temp > 0)
            {
                for (i = 0; i < temp; i++)
                {
                    comboboxDeviceIndex.Items.Add(i);
                }
                comboboxDeviceIndex.SelectedIndex = 0;
                btnStart.Enabled = true;
            }
            else
            {
                btnStart.Enabled = false;
            }

            btnStop.Enabled = false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            int i;
            int j;
            int temp;
            byte[] SN = new byte[8];

            //获取设备索引号
            DevIndex = comboboxDeviceIndex.SelectedIndex;

            //打开指定索引号的设备
            temp = USB5000DLL.USB5OpenDevice(DevIndex);

            //显示设备序列号
            temp = USB5000DLL.USB5GetDeviceSN(DevIndex, SN);
            textboxSN.Text = "SN: " + System.Text.Encoding.ASCII.GetString(SN);

            //产生一个由 1000 个 -10 ~ 10V 的随机数组成的波形，存放于 WaveData 中
            for (i = 0; i < 1000; i++)
            {
                WaveData[i] = rd.Next(-10, 10);
            }

            //-----------------------------------------
            //Ao Wave 相关的设置

            //清除 Ao_0 的触发标志
            temp = USB5000DLL.SetUSB5ClrAoTrigger(DevIndex, 0);

            //清空 Ao_0 的硬件 Fifo 空间
            temp = USB5000DLL.SetUSB5ClrAoFifo(DevIndex, 0);

            //设置 Ao_0 输出模式为 计算机缓冲的无限长度不循环波形输出模式
            temp = USB5000DLL.SetUSB5AoSampleMode(DevIndex, 0, 0);

            //设置 Ao_0 输入的采样周期为 10000 ns，即 10us，采样率为 100kHz
            temp = USB5000DLL.SetUSB5AoSampleRate(DevIndex, 0, 10000);

            //设置 Ao_0 触发源为软件触发
            temp = USB5000DLL.SetUSB5AoTrigSource(DevIndex, 0, 0);

            //设置 Ao_0 采样时钟为内部 Ao 采样时钟
            temp = USB5000DLL.SetUSB5AoConvSource(DevIndex, 0, 0);

            //将 1000 个点长度的波形 WaveData 下载到硬件 Fifo 中
            temp = USB5000DLL.SetUSB5AoDataFifo(DevIndex, 0, WaveData, 1000);

            btnStart.Enabled = false;
            btnStop.Enabled = true;
            Rounds = 0;
            Running = 1;

            timer1.Interval = 100;
            timer1.Enabled = true;

            //软件触发 Ao_0
            temp = USB5000DLL.SetUSB5AoSoftTrig(DevIndex, 0);

            //创建一个线程用于源源不断的产生新的数据，并下载到采集卡硬件 Fifo 中
            threadDownload = new Thread(DownloadWaveData);
            threadDownload.Start();
        }

        private void DownloadWaveData()
        {
            int temp;
            int i;

            while (Running == 1)
            {
                //更新波形数据
                for (i = 0; i < 1000; i++)
                {
                    WaveData[i] = rd.Next(-10, 10);
                }

                //将更新后的 1000 个点长度的波形 WaveData 下载到硬件 Fifo 中
                temp = USB5000DLL.SetUSB5AoDataFifo(DevIndex, 0, WaveData, 1000);

                Rounds = Rounds + 1;

                //因为 1000 点的数据能够输出 10ms，所以延时 5ms 之后再产生新的数据并下载，可以保证输出波形的无间断连续性
                Thread.Sleep(5);
            }
        }

        private void CloseDevice()
        {
            int temp;

            if (Running == 1)
            {
                Running = 0;
                threadDownload.Join();

                //清除 Ao_0 触发标志
                temp = USB5000DLL.SetUSB5ClrAoTrigger(DevIndex, 0);

                //清空 Ao_0 硬件 Fifo
                temp = USB5000DLL.SetUSB5ClrAoFifo(DevIndex, 0);

                //关闭设备
                temp = USB5000DLL.USB5CloseDevice(DevIndex);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            CloseDevice();
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseDevice();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            textboxRounds.Text = Rounds.ToString();
        }
    }

    class USB5000DLL
    {
        [DllImport("USB5000.dll")]
        public static extern int FindUSB5DAQ();
        [DllImport("USB5000.dll")]
        public static extern int USB5OpenDevice(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int USB5CloseDevice(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDeviceSN(int DevIndex, byte[] SN);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDeviceModel(int DevIndex, byte[] Model);

        //--------------------------------------------------------------------------
        // Ananlog Input Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSampleMode(int DevIndex, byte AiSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiRange(int DevIndex, byte Chan, float AiRange);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiChanSel(int DevIndex, byte Chan, byte Sel);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiTrigSource(int DevIndex, byte AiTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiConvSource(int DevIndex, byte AiConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiPreTrigPoints(int DevIndex, uint AiPreTrigPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiOneShotPoints(int DevIndex, uint AiOneShotPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAiFifo(int DevIndex);

        //--------------------------------------------------------------------------
        // Digital I/O Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSampleMode(int DevIndex, byte DiSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiTrigSource(int DevIndex, byte DiTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiConvSource(int DevIndex, byte DiConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiPreTrigPoints(int DevIndex, uint DiPreTrigPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiOneShotPoints(int DevIndex, uint DiOneShotPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDiFifo(int DevIndex);

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSampleMode(int DevIndex, byte DoSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoTrigSource(int DevIndex, byte DoTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoConvSource(int DevIndex, byte DoConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoCycle(int DevIndex, uint DoCycle);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoDataFifo(int DevIndex, uint[] Value, uint Len);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDoFifo(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoWaveCtrl(int DevIndex, uint Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoImmediately(int DevIndex, uint Chan, uint Value);

        //--------------------------------------------------------------------------
        // Ananlog Output Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSampleRate(int DevIndex, byte Chan, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSampleMode(int DevIndex, byte Chan, byte AoSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoTrigSource(int DevIndex, byte Chan, byte AoTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoConvSource(int DevIndex, byte Chan, byte AoConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoCycle(int DevIndex, byte Chan, byte AoCycle);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoDataFifo(int DevIndex, byte Chan, float[] Voltage, uint Len);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAoFifo(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSync(int DevIndex, byte Chans);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoImmediately(int DevIndex, byte Chan, float Voltage);

        //--------------------------------------------------------------------------
        // Trig Control

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSoftTrig(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5GlobalSoftTrig(int DevIndex);

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAiTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDiTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDoTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAoTrigger(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrGlobalSoftTrig(int DevIndex);

        //--------------------------------------------------------------------------
        // Sync Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ExtTrigOutSource(int DevIndex, byte Source);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ExtConvOutSource(int DevIndex, byte Source);

        //--------------------------------------------------------------------------
        // Get Data Acquired

        [DllImport("USB5000.dll")]
        public static extern int USB5GetAi(int DevIndex, uint Points, float[] Ai, int TimeOut);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDi(int DevIndex, uint Points, byte[] Di, int TimeOut);
    }
}
