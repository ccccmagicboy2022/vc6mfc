﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;   //必须添加，不然DllImport报错
using System.Threading;

namespace usb_3xxx_di_continuous
{
    public partial class Form1 : Form
    {
        int DevIndex;
        int Running;
        byte[] Model = new byte[4];
        CheckBox[] checkboxAi = new CheckBox[24];
        TextBox[] textboxAiValue = new TextBox[24];
        CheckBox[] checkboxDi = new CheckBox[4];
        CheckBox[] checkboxDo = new CheckBox[4];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int temp;
            int i;

            temp = USB5000DLL.FindUSB5DAQ();
            if (temp > 0)
            {
                for (i = 0; i < temp; i++)
                {
                    comboboxDeviceIndex.Items.Add(i);
                }
                comboboxDeviceIndex.SelectedIndex = 0;
                btnStart.Enabled = true;
            }
            else
            {
                btnStart.Enabled = false;
            }

            for (i = 0; i < 4; i++)
            {
                checkboxDi[i] = new CheckBox();
                checkboxDi[i].Text = "Di " + i;
                checkboxDi[i].Top = 40;
                checkboxDi[i].Left = 100 + 150 * i;
                GroupBox1.Controls.Add(checkboxDi[i]);
            }

            btnStop.Enabled = false;
            Running = 0;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            int i;
            int j;
            int temp;
            byte[] SN = new byte[8];
            byte sel;

            //获取设备索引号
            DevIndex = comboboxDeviceIndex.SelectedIndex;

            //打开指定索引号的设备
            temp = USB5000DLL.USB5OpenDevice(DevIndex);

            //显示设备序列号
            temp = USB5000DLL.USB5GetDeviceSN(DevIndex, SN);
            textboxSN.Text = "SN: " + System.Text.Encoding.ASCII.GetString(SN);

            //-----------------------------------------
            //Di 相关的设置

            //设置采集模式为 连续采集 模式
            temp = USB5000DLL.SetUSB5DiSampleMode(DevIndex, 0);

            //设置 Di 输入的采样周期为 10000 ns，即 10us，采样率为 100kHz
            temp = USB5000DLL.SetUSB5DiSampleRate(DevIndex, 10000);

            //设置 Di 触发源为软件触发
            temp = USB5000DLL.SetUSB5DiTrigSource(DevIndex, 0);

            //设置 Di 采样时钟为 Di 内部采样时钟
            temp = USB5000DLL.SetUSB5DiConvSource(DevIndex, 0);

            //设置 Di 预触发点数为 0
            temp = USB5000DLL.SetUSB5DiPreTrigPoints(DevIndex, 0);

            //清空一次 AiFifo
            temp = USB5000DLL.SetUSB5ClrDiFifo(DevIndex);

            //启动一次软件触发
            temp = USB5000DLL.SetUSB5DiSoftTrig(DevIndex);


            //启动 Timer1
            timer1.Interval = 5;
            timer1.Enabled = true;
            btnStart.Enabled = false;
            btnStop.Enabled = true;
            Running = 1;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int i;
            int j;
            int temp;
            byte[] di = new byte[5000];

            //------------------------------------------------
            //Digital Input 相关的功能

            //从 DiFifo 中每个通道读出 1000 个数，存放在 ai 数组中
            //每次读出来的数据连在一起，将是连续无间断采集得到的一组数据
            temp = USB5000DLL.USB5GetDi(DevIndex, 5000, di, 1000);

            //显示 DiFifo 中还有多少个数据点没被读出来
            //在长时间连续无间断采集的应用中，需注意 temp 数值的变化
            //如果 temp 值在逐渐增大，说明数据处理速度不够快，导致了数据积压在 DiFifo 中
            textboxFifoNum.Text = temp.ToString();

            //显示 Di 连续数据中最新一个状态
            //di 低两位对应两个 Di 通道
            for(i = 0; i < 2; i++)
			{
                checkboxDi[i].CheckState = (CheckState)(di[4999] & 0x01);
                di[4999] = (byte)(di[4999] / 2);
            }
        }

        private void CloseDevice()
        {
            int temp;

            timer1.Enabled = false;
            Thread.Sleep(100);

            //清除硬件触发标志
            temp = USB5000DLL.SetUSB5ClrDiTrigger(DevIndex);
            //清空 Di Fifo
            temp = USB5000DLL.SetUSB5ClrDiFifo(DevIndex);

            //关闭设备
            temp = USB5000DLL.USB5CloseDevice(DevIndex);

            btnStart.Enabled = true;
            btnStop.Enabled = false;
            Running = 0;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            CloseDevice();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Running == 1)
            {
                CloseDevice();
            }
        }
    }

    class USB5000DLL
    {
        [DllImport("USB5000.dll")]
        public static extern int FindUSB5DAQ();
        [DllImport("USB5000.dll")]
        public static extern int USB5OpenDevice(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int USB5CloseDevice(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDeviceSN(int DevIndex, byte[] SN);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDeviceModel(int DevIndex, byte[] Model);

        //--------------------------------------------------------------------------
        // Ananlog Input Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSampleMode(int DevIndex, byte AiSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiRange(int DevIndex, byte Chan, float AiRange);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiChanSel(int DevIndex, byte Chan, byte Sel);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiTrigSource(int DevIndex, byte AiTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiConvSource(int DevIndex, byte AiConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiPreTrigPoints(int DevIndex, uint AiPreTrigPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiOneShotPoints(int DevIndex, uint AiOneShotPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAiFifo(int DevIndex);

        //--------------------------------------------------------------------------
        // Digital I/O Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSampleMode(int DevIndex, byte DiSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiTrigSource(int DevIndex, byte DiTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiConvSource(int DevIndex, byte DiConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiPreTrigPoints(int DevIndex, uint DiPreTrigPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiOneShotPoints(int DevIndex, uint DiOneShotPoints);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDiFifo(int DevIndex);

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSampleRate(int DevIndex, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSampleMode(int DevIndex, byte DoSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoTrigSource(int DevIndex, byte DoTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoConvSource(int DevIndex, byte DoConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoCycle(int DevIndex, uint DoCycle);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoDataFifo(int DevIndex, uint[] Value, uint Len);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDoFifo(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoWaveCtrl(int DevIndex, uint Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoImmediately(int DevIndex, uint Chan, uint Value);

        //--------------------------------------------------------------------------
        // Ananlog Output Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSampleRate(int DevIndex, byte Chan, uint SamplePeriod);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSampleMode(int DevIndex, byte Chan, byte AoSampleMode);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoTrigSource(int DevIndex, byte Chan, byte AoTrigSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoConvSource(int DevIndex, byte Chan, byte AoConvSource);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoCycle(int DevIndex, byte Chan, byte AoCycle);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoDataFifo(int DevIndex, byte Chan, float[] Voltage, uint Len);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAoFifo(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSync(int DevIndex, byte Chans);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoImmediately(int DevIndex, byte Chan, float Voltage);

        //--------------------------------------------------------------------------
        // Trig Control

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AiSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DiSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5DoSoftTrig(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5AoSoftTrig(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5GlobalSoftTrig(int DevIndex);

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAiTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDiTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrDoTrigger(int DevIndex);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrAoTrigger(int DevIndex, byte Chan);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ClrGlobalSoftTrig(int DevIndex);

        //--------------------------------------------------------------------------
        // Sync Configuration

        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ExtTrigOutSource(int DevIndex, byte Source);
        [DllImport("USB5000.dll")]
        public static extern int SetUSB5ExtConvOutSource(int DevIndex, byte Source);

        //--------------------------------------------------------------------------
        // Get Data Acquired

        [DllImport("USB5000.dll")]
        public static extern int USB5GetAi(int DevIndex, uint Points, float[] Ai, int TimeOut);
        [DllImport("USB5000.dll")]
        public static extern int USB5GetDi(int DevIndex, uint Points, byte[] Di, int TimeOut);
    }
}
