﻿namespace usb_3xxx_getting_started
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboboxDeviceIndex = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.textboxAO_3 = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.textboxAO_2 = new System.Windows.Forms.TextBox();
            this.textboxAO_1 = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.textboxAO_0 = new System.Windows.Forms.TextBox();
            this.textboxModel = new System.Windows.Forms.TextBox();
            this.textboxSN = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.GroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboboxDeviceIndex
            // 
            this.comboboxDeviceIndex.FormattingEnabled = true;
            this.comboboxDeviceIndex.Location = new System.Drawing.Point(140, 12);
            this.comboboxDeviceIndex.Name = "comboboxDeviceIndex";
            this.comboboxDeviceIndex.Size = new System.Drawing.Size(121, 20);
            this.comboboxDeviceIndex.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "DeviceIndex: ";
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(560, 10);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 8;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(479, 10);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 7;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Location = new System.Drawing.Point(12, 38);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(249, 198);
            this.GroupBox1.TabIndex = 9;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Analog Input Channel Select";
            // 
            // GroupBox2
            // 
            this.GroupBox2.Location = new System.Drawing.Point(267, 39);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(478, 198);
            this.GroupBox2.TabIndex = 10;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Analog Input";
            // 
            // GroupBox5
            // 
            this.GroupBox5.Location = new System.Drawing.Point(532, 243);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(213, 126);
            this.GroupBox5.TabIndex = 13;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "Digital Output";
            // 
            // GroupBox4
            // 
            this.GroupBox4.Location = new System.Drawing.Point(314, 243);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(212, 126);
            this.GroupBox4.TabIndex = 12;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Digital Input";
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.textboxAO_3);
            this.GroupBox3.Controls.Add(this.Label4);
            this.GroupBox3.Controls.Add(this.Label5);
            this.GroupBox3.Controls.Add(this.textboxAO_2);
            this.GroupBox3.Controls.Add(this.textboxAO_1);
            this.GroupBox3.Controls.Add(this.Label3);
            this.GroupBox3.Controls.Add(this.Label2);
            this.GroupBox3.Controls.Add(this.textboxAO_0);
            this.GroupBox3.Location = new System.Drawing.Point(12, 243);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(296, 126);
            this.GroupBox3.TabIndex = 11;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Analog Output";
            // 
            // textboxAO_3
            // 
            this.textboxAO_3.Location = new System.Drawing.Point(204, 77);
            this.textboxAO_3.Name = "textboxAO_3";
            this.textboxAO_3.Size = new System.Drawing.Size(58, 21);
            this.textboxAO_3.TabIndex = 7;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(157, 80);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(41, 12);
            this.Label4.TabIndex = 6;
            this.Label4.Text = "AO 3: ";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(157, 40);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(41, 12);
            this.Label5.TabIndex = 5;
            this.Label5.Text = "AO 2: ";
            // 
            // textboxAO_2
            // 
            this.textboxAO_2.Location = new System.Drawing.Point(204, 37);
            this.textboxAO_2.Name = "textboxAO_2";
            this.textboxAO_2.Size = new System.Drawing.Size(58, 21);
            this.textboxAO_2.TabIndex = 4;
            // 
            // textboxAO_1
            // 
            this.textboxAO_1.Location = new System.Drawing.Point(72, 77);
            this.textboxAO_1.Name = "textboxAO_1";
            this.textboxAO_1.Size = new System.Drawing.Size(58, 21);
            this.textboxAO_1.TabIndex = 3;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(25, 80);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(41, 12);
            this.Label3.TabIndex = 2;
            this.Label3.Text = "AO 1: ";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(25, 40);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(41, 12);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "AO 0: ";
            // 
            // textboxAO_0
            // 
            this.textboxAO_0.Location = new System.Drawing.Point(72, 37);
            this.textboxAO_0.Name = "textboxAO_0";
            this.textboxAO_0.Size = new System.Drawing.Size(58, 21);
            this.textboxAO_0.TabIndex = 0;
            // 
            // textboxModel
            // 
            this.textboxModel.Location = new System.Drawing.Point(373, 12);
            this.textboxModel.Name = "textboxModel";
            this.textboxModel.Size = new System.Drawing.Size(100, 21);
            this.textboxModel.TabIndex = 15;
            // 
            // textboxSN
            // 
            this.textboxSN.Location = new System.Drawing.Point(267, 12);
            this.textboxSN.Name = "textboxSN";
            this.textboxSN.Size = new System.Drawing.Size(100, 21);
            this.textboxSN.TabIndex = 14;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 380);
            this.Controls.Add(this.textboxModel);
            this.Controls.Add(this.textboxSN);
            this.Controls.Add(this.GroupBox5);
            this.Controls.Add(this.GroupBox4);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboboxDeviceIndex);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ComboBox comboboxDeviceIndex;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Button btnStop;
        internal System.Windows.Forms.Button btnStart;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.TextBox textboxAO_3;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox textboxAO_2;
        internal System.Windows.Forms.TextBox textboxAO_1;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox textboxAO_0;
        internal System.Windows.Forms.TextBox textboxModel;
        internal System.Windows.Forms.TextBox textboxSN;
        private System.Windows.Forms.Timer timer1;
    }
}

